原2024 BDDM会议改投，文章信息如下：

ciotsc2024-30-Landmark Selection Strategy to Accelerate Shortest Distance Queries

PDF文件夹提供单栏和双栏格式，一起提供给组委会，论文内容完全一致。

source文件夹为论文latex文件包。论文中使用的图片在latex压缩包下的figure文件夹。

supplemental提供完整的源文件latex压缩包。


若有问题，烦请组委会联系作者：2112233062@e.gzhu.edu.cn
